#!/bin/bash
echo "Bonjour vous avez rentré $# paramètres" #Affiche le nb de paramètre
echo "Le nom du script est $0" #Affiche le  nom du script
echo "Le 3ème paramètre est $3" #Affiche le 3ème paramètre
echo "Voici la liste des paramètres : $@" #Affiche la liste des paramètres